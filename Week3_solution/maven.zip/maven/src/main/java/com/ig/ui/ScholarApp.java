package com.ig.ui;

import com.ig.service.ScholarService;
import com.ig.model.Scholar;
import com.ig.exception.ScholarNotFoundException;

import java.util.Scanner;

public class ScholarApp {
    public static void main(String[] args) throws Exception {
        ScholarService service = new ScholarService();
        Scanner scanner = new Scanner(System.in);

        // Insert 5 Scholars
        System.out.println("\nAdding 5 Scholars...");
        service.addScholar(new Scholar(11, "John Doe", "john@example.com", "1234567890"));
        service.addScholar(new Scholar(12, "Alice", "alice@gmail.com", "9876543210"));
        service.addScholar(new Scholar(13, "Bob", "bob@gmail.com", "8976541230"));
        service.addScholar(new Scholar(14, "Charlie", "charlie@gmail.com", "7894561230"));
        service.addScholar(new Scholar(15, "David", "david@gmail.com", "8523697410"));

        // List all scholars with column names
        System.out.println("\nListing all scholars:");
        service.listAllScholars();

        // Get a single scholar
        System.out.print("\nEnter Scholar ID to retrieve: ");
        int scholarId = scanner.nextInt();
        try {
            Scholar scholar = service.getOneScholar(scholarId);
            System.out.println("Scholar Found: " + scholar);
        } catch (ScholarNotFoundException e) {
            System.out.println(e.getMessage());
        }

        // Update scholar email
        System.out.print("\nEnter Scholar ID to update email: ");
        scholarId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter new Email: ");
        String newEmail = scanner.nextLine();
        try {
            service.updateScholarEmail(scholarId, newEmail);
            System.out.println("Email updated successfully.");
        } catch (ScholarNotFoundException e) {
            System.out.println(e.getMessage());
        }

        // Delete a scholar
        System.out.print("\nEnter Scholar ID to delete: ");
        scholarId = scanner.nextInt();
        try {
            service.deleteScholarById(scholarId);
            System.out.println("Scholar deleted successfully.");
        } catch (ScholarNotFoundException e) {
            System.out.println(e.getMessage());
        }

        // Show the final list
        System.out.println("\nFinal list of scholars:");
        service.listAllScholars();

        scanner.close();
    }
}
