package com.ig.dao;

import com.ig.model.Scholar;
import com.ig.util.DbUtil;
import com.ig.exception.ScholarNotFoundException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ScholarDao {

    public void addScholar(Scholar scholar) throws SQLException, ClassNotFoundException {
        Connection con = DbUtil.getConnection();
        String sql = "INSERT INTO Scholar (Rollno, Name, Email, Mobile) VALUES (?, ?, ?, ?)";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setInt(1, scholar.getScholarId());
        ps.setString(2, scholar.getName());
        ps.setString(3, scholar.getEmail());
        ps.setString(4, scholar.getMobile());
        ps.executeUpdate();
        con.close();
    }

    // Point 2: Use ResultSetMetaData to get column names dynamically
    public List<Scholar> listAllScholars() throws SQLException, ClassNotFoundException {
        List<Scholar> list = new ArrayList<>();
        Connection con = DbUtil.getConnection();
        String sql = "SELECT * FROM Scholar";
        PreparedStatement ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        ResultSetMetaData metaData = rs.getMetaData();
        int columnCount = metaData.getColumnCount();

        // Print column names dynamically
        System.out.println("\nScholar Table Columns:");
        for (int i = 1; i <= columnCount; i++) {
            System.out.print(metaData.getColumnName(i) + " | ");
        }
        System.out.println("\n--------------------------------------");

        // Fetch and print data
        while (rs.next()) {
            System.out.println(rs.getInt("Rollno") + " | " + rs.getString("Name") + " | " + 
                               rs.getString("Email") + " | " + rs.getString("Mobile"));
            list.add(new Scholar(rs.getInt("Rollno"), rs.getString("Name"), rs.getString("Email"), rs.getString("Mobile")));
        }
        con.close();
        return list;
    }

    public Scholar getOneScholar(Integer scholarId) throws SQLException, ClassNotFoundException, ScholarNotFoundException {
        Connection con = DbUtil.getConnection();
        String sql = "SELECT * FROM Scholar WHERE Rollno = ?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setInt(1, scholarId);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            return new Scholar(rs.getInt("Rollno"), rs.getString("Name"), rs.getString("Email"), rs.getString("Mobile"));
        } else {
            throw new ScholarNotFoundException("Scholar with ID " + scholarId + " not found.");
        }
    }

    public void updateScholarEmail(Integer scholarId, String email) throws SQLException, ClassNotFoundException, ScholarNotFoundException {
        Connection con = DbUtil.getConnection();
        String sql = "UPDATE Scholar SET Email = ? WHERE Rollno = ?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, email);
        ps.setInt(2, scholarId);
        int rowsUpdated = ps.executeUpdate();
        if (rowsUpdated == 0) {
            throw new ScholarNotFoundException("Scholar with ID " + scholarId + " not found.");
        }
        con.close();
    }

    public void deleteScholarById(Integer scholarId) throws SQLException, ClassNotFoundException, ScholarNotFoundException {
        Connection con = DbUtil.getConnection();
        String sql = "DELETE FROM Scholar WHERE Rollno = ?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setInt(1, scholarId);
        int rowsDeleted = ps.executeUpdate();
        if (rowsDeleted == 0) {
            throw new ScholarNotFoundException("Scholar with ID " + scholarId + " not found.");
        }
        con.close();
    }
}
