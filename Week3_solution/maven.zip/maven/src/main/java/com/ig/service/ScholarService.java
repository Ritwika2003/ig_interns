package com.ig.service;

import com.ig.dao.ScholarDao;
import com.ig.model.Scholar;
import com.ig.exception.ScholarNotFoundException;
import java.sql.SQLException;
import java.util.List;

public class ScholarService {
    private ScholarDao dao = new ScholarDao();

    public void addScholar(Scholar scholar) throws SQLException, ClassNotFoundException {
        dao.addScholar(scholar);
    }

    public List<Scholar> listAllScholars() throws SQLException, ClassNotFoundException {
        return dao.listAllScholars();
    }

    public Scholar getOneScholar(Integer scholarId) throws SQLException, ClassNotFoundException, ScholarNotFoundException {
        return dao.getOneScholar(scholarId);
    }

    public void updateScholarEmail(Integer scholarId, String email) throws SQLException, ClassNotFoundException, ScholarNotFoundException {
        dao.updateScholarEmail(scholarId, email);
    }

    public void deleteScholarById(Integer scholarId) throws SQLException, ClassNotFoundException, ScholarNotFoundException {
        dao.deleteScholarById(scholarId);
    }
}