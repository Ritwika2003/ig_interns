package insight_global.week1solution;


import insight_global.week1solution.AccountNotFoundException;
import insight_global.week1solution.InvalidAmountException;
import insight_global.week1solution.InsufficientFundsException;
import insight_global.week1solution.LowBalanceException;

public class AccountTest {

    public static void main(String[] args) {
        AccountService accountService = new AccountService();

        try {
            // Creating account objects and adding them to the list
            Account account1 = new Account(101, "John Doe", Account.AccountType.SAVINGS, 1500.0f);
            Account account2 = new Account(102, "Jane Smith", Account.AccountType.CURRENT, 6000.0f);

            accountService.addAccount(account1);
            accountService.addAccount(account2);

            // Performing operations
            System.out.println("Initial balance of account 101: " + accountService.getBalance(101));

            // Deposit into account 101
            accountService.deposit(101, 2000.0f);
            System.out.println("Balance after deposit in account 101: " + accountService.getBalance(101));

            // Withdraw from account 101
            accountService.withdraw(101, 500.0f);
            System.out.println("Balance after withdrawal in account 101: " + accountService.getBalance(101));

        } catch (AccountNotFoundException | InvalidAmountException | InsufficientFundsException | LowBalanceException e) {
            System.out.println(e.getMessage());
        }
    }
}

