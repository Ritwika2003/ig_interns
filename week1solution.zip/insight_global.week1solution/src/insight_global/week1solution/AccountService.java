package insight_global.week1solution;



import insight_global.week1solution.AccountNotFoundException;
import insight_global.week1solution.InvalidAmountException;
import insight_global.week1solution.InsufficientFundsException;
import insight_global.week1solution.LowBalanceException;

import java.util.ArrayList;
import java.util.List;

public class AccountService {

    private List<Account> accountList = new ArrayList<>();

    // Method to validate whether an account exists by account number
    public boolean isValidAccount(int accNumber) throws AccountNotFoundException {
        for (Account account : accountList) {
            if (account.getAccNumber() == accNumber) {
                return true;
            }
        }
        throw new AccountNotFoundException("Account not found with account number: " + accNumber);
    }

    // Method to deposit money into an account
    public void deposit(int accNumber, float amt) throws AccountNotFoundException, InvalidAmountException {
        if (amt <= 0) {
            throw new InvalidAmountException("Amount should be positive.");
        }

        for (Account account : accountList) {
            if (account.getAccNumber() == accNumber) {
                account.setBalance(account.getBalance() + amt);
                return;
            }
        }
        throw new AccountNotFoundException("Account not found with account number: " + accNumber);
    }

    // Method to withdraw money from an account
    public void withdraw(int accNumber, float amt) throws AccountNotFoundException, InvalidAmountException, InsufficientFundsException {
        if (amt <= 0) {
            throw new InvalidAmountException("Amount should be positive.");
        }

        for (Account account : accountList) {
            if (account.getAccNumber() == accNumber) {
                // Check if withdrawal amount is >= 500
                if (amt < 500) {
                    throw new InvalidAmountException("Minimum withdrawal amount is Rs. 500.");
                }

                // Check if the account type is savings or current and ensure sufficient balance
                if (account.getType() == Account.AccountType.SAVINGS && account.getBalance() - amt < 1000) {
                    throw new InsufficientFundsException("Insufficient funds for withdrawal in savings account.");
                }
                if (account.getType() == Account.AccountType.CURRENT && account.getBalance() - amt < 5000) {
                    throw new InsufficientFundsException("Insufficient funds for withdrawal in current account.");
                }

                // If everything is valid, perform the withdrawal
                account.setBalance(account.getBalance() - amt);
                return;
            }
        }
        throw new AccountNotFoundException("Account not found with account number: " + accNumber);
    }

    // Method to get account balance
    public float getBalance(int accNumber) throws AccountNotFoundException {
        for (Account account : accountList) {
            if (account.getAccNumber() == accNumber) {
                return account.getBalance();
            }
        }
        throw new AccountNotFoundException("Account not found with account number: " + accNumber);
    }

    // Method to add an account to the list (used for testing purposes)
    public void addAccount(Account account) {
        accountList.add(account);
    }
}

