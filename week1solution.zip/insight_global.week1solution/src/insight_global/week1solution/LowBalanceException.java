package insight_global.week1solution;

public class LowBalanceException extends Exception {
    public LowBalanceException(String message) {
        super(message);
    }
}
