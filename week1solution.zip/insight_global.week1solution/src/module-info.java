/**
 * 
 */
/**
 * 
 */
module insight_global.week1solution {
}