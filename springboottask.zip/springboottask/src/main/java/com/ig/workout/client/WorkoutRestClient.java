package com.ig.workout.client;

import com.ig.workout.model.Workout;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import java.util.Arrays;
import java.util.List;

@Component
public class WorkoutRestClient {

    private final RestTemplate restTemplate = new RestTemplate();
    private final String BASE_URL = "http://localhost:8080/api/workouts";

    public void addWorkout() {
        Workout workout = new Workout("Morning Walk", 30, 100, "morningwalk");
        restTemplate.postForObject(BASE_URL, workout, Workout.class);
        System.out.println("Workout added successfully.");
    }

    public void getAllWorkouts() {
        List<Workout> workouts = Arrays.asList(restTemplate.getForObject(BASE_URL, Workout[].class));
        workouts.forEach(System.out::println);
    }
}